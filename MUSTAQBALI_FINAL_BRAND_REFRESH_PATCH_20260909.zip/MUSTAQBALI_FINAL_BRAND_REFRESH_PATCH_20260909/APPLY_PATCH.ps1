$ErrorActionPreference = 'Stop'
$ExpectedHead = 'aead74631a3f8cacf04595f0e299728bb88126ef'

if (-not (Test-Path '.\package.json')) {
  throw 'شغّل هذا الملف من جذر مستودع Noor المحلي (المجلد الذي يحتوي package.json).'
}

$dirty = git status --porcelain
if ($dirty) {
  throw 'المستودع يحتوي تعديلات غير محفوظة. اعمل commit/stash أولاً ثم أعد المحاولة.'
}

git fetch origin main
$head = (git rev-parse HEAD).Trim()
$origin = (git rev-parse origin/main).Trim()
if ($head -ne $origin) {
  throw "النسخة المحلية ليست مساوية لـ origin/main. HEAD=$head origin/main=$origin"
}
if ($head -ne $ExpectedHead) {
  throw "تغيّر main بعد تجهيز الحزمة. توقفت الحزمة حمايةً من الكتابة فوق تحديثات أحدث. HEAD=$head"
}

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = Join-Path $root 'payload'
Get-ChildItem $payload -File -Recurse | ForEach-Object {
  $relative = $_.FullName.Substring($payload.Length + 1)
  $target = Join-Path (Get-Location) $relative
  $targetDir = Split-Path -Parent $target
  if (-not (Test-Path $targetDir)) { New-Item -ItemType Directory -Force -Path $targetDir | Out-Null }
  Copy-Item -Force $_.FullName $target
}

Write-Host 'تم تطبيق تحديث الهوية محلياً.' -ForegroundColor Green
Write-Host 'التحقق المقترح:' -ForegroundColor Cyan
Write-Host '  npm run quality:gate'
Write-Host 'ثم بعد النجاح:'
Write-Host '  git add .'
Write-Host '  git commit -m "Apply final Mustaqbali brand identity and Vercel auth origin fix"'
Write-Host '  git push'
